package CartaCafe.CartaCafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartaCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartaCafeApplication.class, args);
	}

}
